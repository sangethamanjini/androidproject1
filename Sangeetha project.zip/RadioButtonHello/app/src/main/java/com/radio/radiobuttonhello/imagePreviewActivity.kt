package com.radio.radiobuttonhello

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ImagePreviewActivity : AppCompatActivity() {

    private val pickImage = 100
    private var imageUri: Uri? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.image_upload)
        val message = intent.getStringExtra("message_key")
        val messageTextView: TextView = findViewById(R.id.message)
        messageTextView.text = message
        val submit: Button = findViewById(R.id.loadPicture)
        submit.setOnClickListener {
            val gallery = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            startActivityForResult(gallery, pickImage)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == pickImage) {
            imageUri = data?.data
            val intent = Intent(this, ImageUpload::class.java)
            intent.putExtra("imageUrl",imageUri.toString())
            startActivity(intent)
            finish()
            //imageView.setImageURI(imageUri)
        }
    }
}