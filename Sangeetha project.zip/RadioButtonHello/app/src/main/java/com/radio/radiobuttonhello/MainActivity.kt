package com.radio.radiobuttonhello

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    var radioGroup: RadioGroup? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        radioGroup = findViewById(R.id.radio_group)
        val utilityRadio: RadioButton = findViewById(R.id.utility)
        val bankRadio: RadioButton = findViewById(R.id.bank)
        val loanRadio: RadioButton = findViewById(R.id.loan)
        val creditRadio: RadioButton = findViewById(R.id.credit)
        val submit: Button = findViewById(R.id.submit)
        utilityRadio.setOnClickListener({});
        bankRadio.setOnClickListener({});
        loanRadio.setOnClickListener({});
        creditRadio.setOnClickListener({});
        submit.setOnClickListener {
            if (bankRadio.isChecked) {
                val intent = Intent(this@MainActivity, ImagePreviewActivity::class.java)
                intent.putExtra("message_key",bankRadio.text )
                startActivity(intent)
            } else if (loanRadio.isChecked) {
                val intent = Intent(this@MainActivity, ImagePreviewActivity::class.java)
                intent.putExtra("message_key",loanRadio.text )
                startActivity(intent)
            } else if (creditRadio.isChecked) {
                val intent = Intent(this@MainActivity, ImagePreviewActivity::class.java)
                intent.putExtra("message_key",creditRadio.text )
                startActivity(intent)
                //Toast.makeText(getApplicationContext(), creditRadio.text, Toast.LENGTH_LONG).show();
            } else if (utilityRadio.isChecked) {
                val intent = Intent(this@MainActivity, ImagePreviewActivity::class.java)
                intent.putExtra("message_key",utilityRadio.text )
                startActivity(intent)
            }else{
                Toast.makeText(getApplicationContext(), "Please select document type", Toast.LENGTH_LONG).show();
            }

        };
    }

}