package com.radio.radiobuttonhello

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ImageUpload : AppCompatActivity() {
    lateinit var imageView: ImageView
    lateinit var button: Button
    lateinit var reTakeImage: Button
    private val pickImage = 100
    private var imageUri: Uri? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.image_preview)
        imageView = findViewById(R.id.imageView)

        val message = intent.getStringExtra("imageUrl")
        var myUri = Uri.parse(message.toString());
        imageView.setImageURI(myUri);
        button = findViewById(R.id.confirmUpload)
        reTakeImage = findViewById(R.id.reUploadPicture)
        button.setOnClickListener {

            finish()
            finish()
            Toast.makeText(
                getApplicationContext(),
                "Document Uploaded Successfully",
                Toast.LENGTH_LONG
            ).show();
        }
        reTakeImage.setOnClickListener {
            val gallery = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            startActivityForResult(gallery, pickImage)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == pickImage) {
            imageUri = data?.data
            imageView.setImageURI(imageUri)
        }
    }
}

